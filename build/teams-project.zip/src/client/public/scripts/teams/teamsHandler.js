const main = async() => {
    'use strict';
    await microsoftTeams.app.initialize();

    const context = await microsoftTeams.app.getContext();

    console.log(context)
}
main()